# Database bootstrap

## First local database apply

You can apply the initial SQL directly against Postgres before moving to generated Drizzle migrations.

### Option A — psql

```bash
psql "$DATABASE_URL" -f infra/sql/001_init.sql
```

### Option B — Supabase SQL editor

Paste the contents of `infra/sql/001_init.sql` into the SQL editor and run it.

## Drizzle workflow

Generate migrations:

```bash
pnpm db:generate
```

Apply migrations:

```bash
pnpm db:migrate
```

Open Drizzle Studio:

```bash
pnpm db:studio
```

- `002_myob_token_exchange.sql` — adds tenant-scoped MYOB OAuth token storage for token exchange + callback persistence.

- 014_suppliers_legacy_columns_fix.sql — repair migration for older app.suppliers tables missing contact/email/phone/status/notes fields.

- `038_wordpress_product_publishing.sql` — adds website publishing fields to products, tenant-scoped WordPress API connections, and idempotent WooCommerce order tracking.

- `039_quote_line_client_responses.sql` — adds persistent per-line client quote response status, notes and timestamps for approve/change/cancel workflows.

- `040_artwork_revision_proof_tracking.sql` — tracks which artwork revision each uploaded proof belongs to so revised packs cannot accidentally resend an older proof.

- `044_artwork_page_responses.sql` — adds independent client decisions and notes to each artwork proof page, with a compatibility backfill for already-approved proof sets.

- `045_job_process_staff_assignments.sql` — adds multi-staff ownership and due dates for each job process, plus inherited or overridden production-step assignments.
