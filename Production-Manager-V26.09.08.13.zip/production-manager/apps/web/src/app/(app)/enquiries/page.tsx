
import Link from "next/link";
import { redirect } from "next/navigation";
import { getRequiredSessionUser } from "@/server/auth/session";
import { resolveActiveTenantForAuthUserId } from "@/server/bootstrap/activeTenant";
import { listEnquiriesForTenant, listRecentEnquiryCorrespondenceForTenant, reconcileEnquiryWorkflowStatusesForTenant } from "@/server/enquiries";
import { customerLogoUrl, listCustomersForTenant } from "@/server/customers";
import { attachEnquiryCorrespondenceAction, createSurveyFromEnquiryAction, deleteEnquiryAction, restoreEnquiryAction } from "./actions";
import { EnquiryCorrespondenceDropzone } from "./EnquiryCorrespondenceDropzone";
import { EnquiryCorrespondencePreview } from "./EnquiryCorrespondencePreview";
import { NewEnquiryForm } from "./NewEnquiryForm";
import { ClientLogoBadge } from "@/components/ClientLogoBadge";


type PageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

function readParam(params: Record<string, string | string[] | undefined>, key: string): string {
  const value = params[key];
  if (Array.isArray(value)) return value[0] ?? "";
  return value ?? "";
}

function cardStyle() {
  return { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 20, padding: 22 } as const;
}

function urgencyBadgeStyle(urgency: string | null | undefined) {
  const value = String(urgency ?? "Normal").toLowerCase();
  if (value === "critical" || value === "urgent") return { background: "#fff1f3", color: "#c01048", borderColor: "#fecdd6" } as const;
  if (value === "high") return { background: "#fff7ed", color: "#c2410c", borderColor: "#fed7aa" } as const;
  if (value === "low") return { background: "#f0fdf4", color: "#15803d", borderColor: "#bbf7d0" } as const;
  return { background: "#eff6ff", color: "#1d4ed8", borderColor: "#bfdbfe" } as const;
}


export default async function EnquiriesPage({ searchParams }: PageProps) {
  const user = await getRequiredSessionUser();
  const activeTenant = await resolveActiveTenantForAuthUserId(user.id);
  if (!activeTenant) redirect("/bootstrap");
  const params = (await searchParams) ?? {};
  const message = readParam(params, "message");
  const error = readParam(params, "error");
  const filter = readParam(params, "filter");
  const selectedEnquiry = readParam(params, "selectedEnquiry");
  await reconcileEnquiryWorkflowStatusesForTenant(activeTenant.tenantId);
  const [allEnquiries, clients, correspondence] = await Promise.all([
    listEnquiriesForTenant(activeTenant.tenantId, { includeDeleted: true }),
    listCustomersForTenant(activeTenant.tenantId),
    listRecentEnquiryCorrespondenceForTenant(activeTenant.tenantId, 5)
  ]);
  const deletedCount = allEnquiries.filter((enquiry) => enquiry.status === "deleted").length;
  const completedCount = allEnquiries.filter((enquiry) => enquiry.status === "converted").length;
  const enquiries = filter === "deleted"
    ? allEnquiries.filter((enquiry) => enquiry.status === "deleted")
    : filter === "completed"
      ? allEnquiries.filter((enquiry) => enquiry.status === "converted")
      : allEnquiries.filter((enquiry) => enquiry.status !== "deleted" && enquiry.status !== "converted");
  const correspondenceByEnquiry = new Map<string, typeof correspondence>();
  for (const item of correspondence) {
    const existing = correspondenceByEnquiry.get(item.enquiryId) ?? [];
    existing.push(item);
    correspondenceByEnquiry.set(item.enquiryId, existing);
  }

  return (
    <div style={{ maxWidth: 1300, margin: "0 auto", display: "grid", gap: 16 }}>
      <style>{`
        .enquiry-preview-summary::-webkit-details-marker { display: none; }
        .enquiry-preview-summary::marker { content: ""; }
        .enquiry-preview-card .enquiry-preview-summary:hover { background: #f8fbff; }
        .enquiry-preview-card[open] .enquiry-preview-summary { background: #fbfdff; }
      `}</style>
      {message ? <section style={{ border: "1px solid #abefc6", background: "#ecfdf3", color: "#067647", borderRadius: 16, padding: 14 }}>{message}</section> : null}
      {error ? <section style={{ border: "1px solid #fda29b", background: "#fff5f4", color: "#b42318", borderRadius: 16, padding: 14 }}>{error}</section> : null}

      <section style={{ ...cardStyle(), display: "flex", justifyContent: "space-between", gap: 18, alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ display: "grid", gap: 8, minWidth: 0 }}>
          <p style={{ margin: 0, fontSize: 12, fontWeight: 800, letterSpacing: "0.08em", textTransform: "uppercase", color: "#4f46e5" }}>Enquiries</p>
          <h1 style={{ margin: 0 }}>Quick intake first</h1>
          <p style={{ margin: 0, color: "#475467", lineHeight: 1.6 }}>Capture the client, a rough requirement, and decide the next step later. This does not need to tie to MYOB immediately.</p>
        </div>
        <Link
          href="/enquiries/tablet"
          style={{
            minHeight: 48,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "0 18px",
            borderRadius: 14,
            background: "#155eef",
            color: "#fff",
            fontWeight: 900,
            textDecoration: "none",
            boxShadow: "0 10px 24px rgba(21, 94, 239, 0.22)",
            whiteSpace: "nowrap"
          }}
        >
          Open Tablet Mode
        </Link>
      </section>

      <div style={{ display: "grid", gridTemplateColumns: "420px minmax(0, 1fr)", gap: 16, alignItems: "start" }}>
        <NewEnquiryForm clients={clients} />

        <section style={{ ...cardStyle(), display: "grid", gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
            <h2 style={{ margin: 0 }}>{filter === "deleted" ? "Deleted enquiries" : filter === "completed" ? "Completed enquiries" : "Current enquiries"}</h2>
            <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
              <a href="/enquiries" style={{ color: !filter ? "#155eef" : "#667085", fontWeight: 800, textDecoration: "none" }}>Active</a>
              <a href="/enquiries?filter=completed" style={{ color: filter === "completed" ? "#155eef" : "#667085", fontWeight: 800, textDecoration: "none" }}>Completed ({completedCount})</a>
              <a href="/enquiries?filter=deleted" style={{ color: filter === "deleted" ? "#155eef" : "#667085", fontWeight: 800, textDecoration: "none" }}>Deleted ({deletedCount})</a>
              <span style={{ fontSize: 13, color: "#667085" }}>{enquiries.length} shown</span>
            </div>
          </div>
          <div style={{ display: "grid", gap: 12 }}>
            {enquiries.map((enquiry) => {
              const linkedClient = clients.find((client) => client.id === enquiry.linkedCustomerId) ?? null;
              const logoUrl = enquiry.clientLogoUrl || customerLogoUrl(linkedClient);
              const enquiryCorrespondence = correspondenceByEnquiry.get(enquiry.id) ?? [];
              const correspondenceCount = enquiryCorrespondence[0]?.totalCount ?? enquiryCorrespondence.length;
              const contactLine = [enquiry.contactName, enquiry.phone, enquiry.email, enquiry.siteAddress].filter(Boolean).join(" · ");
              const purchaseOrderLine = enquiry.clientPurchaseOrderNumber ? `PO: ${enquiry.clientPurchaseOrderNumber}` : "";

              return (
                <details id={`enquiry-${enquiry.id}`} key={enquiry.id} open={selectedEnquiry === enquiry.id} className="enquiry-preview-card" style={{ border: "1px solid #e5e7eb", borderRadius: 16, background: "#fff", overflow: "hidden", scrollMarginTop: 88 }}>
                  <summary className="enquiry-preview-summary" style={{ cursor: "pointer", listStyle: "none", padding: 12, display: "grid", gap: 8 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "start" }}>
                      <div style={{ display: "flex", gap: 12, alignItems: "start", minWidth: 0 }}>
                        <ClientLogoBadge logoUrl={logoUrl} name={enquiry.clientName} size={46} radius={12} padding={4} />
                        <div style={{ minWidth: 0 }}>
                          <strong style={{ overflowWrap: "anywhere" }}>{enquiry.clientName}</strong>
                          <div style={{ color: "#475467", marginTop: 4, overflowWrap: "anywhere" }}>{enquiry.requestSummary}</div>
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end", flex: "0 0 auto" }}>
                        <span style={{ borderRadius: 999, border: `1px solid ${urgencyBadgeStyle(enquiry.urgency).borderColor}`, ...urgencyBadgeStyle(enquiry.urgency), padding: "4px 10px", fontSize: 12, fontWeight: 900 }}>{enquiry.urgency || "Normal"}</span>
                        <span style={{ borderRadius: 999, background: "#eef2ff", color: "#4338ca", padding: "4px 10px", fontSize: 12, fontWeight: 800 }}>{enquiry.status === "converted" ? "Converted to job" : enquiry.status === "survey_requested" ? "Survey requested" : enquiry.status === "quoted" ? "Quoted" : enquiry.status}</span>
                      </div>
                    </div>
                    {contactLine ? <div style={{ color: "#667085", fontSize: 13 }}>{contactLine}</div> : null}
                    {purchaseOrderLine ? <div style={{ color: "#475467", fontSize: 13, fontWeight: 800 }}>{purchaseOrderLine}</div> : null}
                  </summary>

                  <div style={{ display: "grid", gap: 10, borderTop: "1px solid #eef2f7", padding: "10px 12px 12px" }}>
                    <details style={{ border: "1px solid #e6edf7", borderRadius: 14, background: "#fbfdff", overflow: "hidden" }}>
                      <summary style={{ cursor: "pointer", padding: "10px 12px", color: "#2463eb" }}>
                        <span style={{ display: "inline-flex", width: "calc(100% - 20px)", justifyContent: "space-between", gap: 10, alignItems: "center", verticalAlign: "middle" }}>
                          <strong style={{ fontSize: 13, color: "#111827" }}>Correspondence</strong>
                          <span style={{ fontSize: 12, color: "#667085", whiteSpace: "nowrap" }}>{correspondenceCount} attached</span>
                        </span>
                      </summary>
                      <section style={{ display: "grid", gap: 8, borderTop: "1px solid #e6edf7", padding: "10px 12px 12px" }}>
                        {enquiryCorrespondence.length > 0 ? (
                          <div style={{ display: "grid", gap: 8 }}>
                            {enquiryCorrespondence.slice(0, 5).map((item) => (
                              <EnquiryCorrespondencePreview key={item.id} item={item} />
                            ))}
                          </div>
                        ) : (
                          <span style={{ color: "#98a2b3", fontSize: 12 }}>No email correspondence attached yet.</span>
                        )}
                        {enquiry.status !== "deleted" && enquiry.status !== "converted" ? (
                          <form action={attachEnquiryCorrespondenceAction} style={{ margin: 0 }}>
                            <input type="hidden" name="enquiryId" value={enquiry.id} />
                            <EnquiryCorrespondenceDropzone />
                          </form>
                        ) : null}
                      </section>
                    </details>

                    <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                      {enquiry.status !== "deleted" && enquiry.status !== "converted" ? (
                        <>
                          <form action={createSurveyFromEnquiryAction} style={{ margin: 0 }}>
                            <input type="hidden" name="enquiryId" value={enquiry.id} />
                            <button type="submit" style={{ minHeight: 40, display: "inline-flex", alignItems: "center", padding: "0 14px", borderRadius: 12, border: "1px solid #d0d5dd", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" }}>Create site survey request</button>
                          </form>
                          <Link href={`/surveys?fromEnquiry=${enquiry.id}`} style={{ textDecoration: "none", minHeight: 40, display: "inline-flex", alignItems: "center", padding: "0 14px", borderRadius: 12, border: "1px solid #d0d5dd", color: "#111827", fontWeight: 700 }}>Open survey form</Link>
                        </>
                      ) : null}
                      {enquiry.status !== "deleted" && enquiry.status !== "converted" ? <Link href={`/quotes?fromEnquiry=${enquiry.id}`} style={{ textDecoration: "none", minHeight: 40, display: "inline-flex", alignItems: "center", padding: "0 14px", borderRadius: 12, background: "#111827", color: "#fff", fontWeight: 800 }}>Create quote</Link> : null}
                      {enquiry.status === "deleted" ? (
                        <form action={restoreEnquiryAction} style={{ margin: 0 }}>
                          <input type="hidden" name="enquiryId" value={enquiry.id} />
                          <button type="submit" style={{ minHeight: 40, display: "inline-flex", alignItems: "center", padding: "0 14px", borderRadius: 12, border: "1px solid #d0d5dd", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" }}>Restore enquiry</button>
                        </form>
                      ) : (
                        <form action={deleteEnquiryAction} style={{ margin: 0 }}>
                          <input type="hidden" name="enquiryId" value={enquiry.id} />
                          <button type="submit" style={{ minHeight: 40, display: "inline-flex", alignItems: "center", padding: "0 14px", borderRadius: 12, border: "1px solid #fda29b", background: "#fff5f4", color: "#b42318", fontWeight: 800, cursor: "pointer" }}>Delete</button>
                        </form>
                      )}
                    </div>
                  </div>
                </details>
              );
            })}
            {enquiries.length === 0 ? <p style={{ margin: 0, color: "#667085" }}>No enquiries yet.</p> : null}
          </div>
        </section>
      </div>
    </div>
  );
}
